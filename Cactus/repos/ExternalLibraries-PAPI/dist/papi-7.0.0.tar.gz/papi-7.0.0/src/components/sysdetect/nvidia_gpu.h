#ifndef __NVIDIA_GPU_H__
#define __NVIDIA_GPU_H__

void open_nvidia_gpu_dev_type( _sysdetect_dev_type_info_t *dev_type_info );
void close_nvidia_gpu_dev_type( _sysdetect_dev_type_info_t *dev_type_info );

#endif /* End of __NVIDIA_GPU_H__ */

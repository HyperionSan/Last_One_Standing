# Necessary to configure NVML, on Peak.
./configure --with-nvml-libdir=/usr/lib64/nvidia --with-nvml-incdir=/usr/local --with-cuda-dir=/usr/lib64/nvidia
export CUDA_DIR=/usr/local/cuda-9.2

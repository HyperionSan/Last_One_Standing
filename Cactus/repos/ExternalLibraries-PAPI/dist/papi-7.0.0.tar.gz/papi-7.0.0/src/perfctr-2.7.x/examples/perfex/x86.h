/* $Id: x86.h,v 1.1 2004/01/11 22:07:12 mikpe Exp $
 * x86-specific declarations.
 *
 * Copyright (C) 1999-2004  Mikael Pettersson
 */

#define ARCH_LONG_OPTIONS	\
    { "p4pe", 1, NULL, 1 }, { "p4_pebs_enable", 1, NULL, 1 }, \
    { "p4pmv", 1, NULL, 2 }, { "p4_pebs_matrix_vert", 1, NULL, 2 },
